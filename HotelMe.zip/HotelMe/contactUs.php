<HTML>
<HEAD>
<link rel="stylesheet" href="./css/contactUs.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="./photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id="logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="./photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="index.php">Home</a></li>
<li><a href="aboutUs.php">About Us</a></li>
<li></li>
<li><a href="contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="index.php">Login</a></li>
<li></li>
<li></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="contactbox">
<h1 id ="contactTitle">Contact Us!</h1>
<br>
<p Style="color:white;">Contact us via email at CustomerService@hotelme.com</p><br>
<p Style="color:white;">Or</p><br>
<p Style="color:white;">Contact us toll free by phone at: 1-800-662-6404</p>
</div>


</BODY>
</HTML>