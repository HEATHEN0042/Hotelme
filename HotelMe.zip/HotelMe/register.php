<?php 
$hostname = "naplesbait.com";
$username = "hmservice";
$password = "service";
$dbname = "hotelme";
$conn = new mysqli($hostname,$username,$password,$dbname);

if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
?>

<?php
$FName = ($_POST["FN"]);
$LName = ($_POST["LN"]);
$SA = ($_POST["SA"]);
$City = ($_POST["City"]);
$State = ($_POST["ST"]);
$Zip = ($_POST["Zip"]);
$Email = ($_POST["Email"]);
$Password1 = ($_POST["Password1"]);
$Password2 = ($_POST["Password2"]);

if (isset($_POST["submit"])) {

	$sqlEmail = "SELECT * FROM Customers WHERE Email='$Email'"; 
	$emailResult = mysqli_query($conn,$sqlEmail);
	$emailCheck = mysqli_num_rows($emailResult);
  	
		if($emailCheck == 1){
		echo "<script>alert('Email Already Exists. Please Use Another Email Address.'); window.location.href='./signup.php';</script>";
		}
		else{
			if($Password1==$Password2){
			$sql = "INSERT INTO Customers(FName,LName,StreetAddress,City,State,Zip,Email,Password)VALUES('$FName','$LName','$SA','$City','$State','$Zip','$Email','$Password1')";

				if ($conn->query($sql) === TRUE) {
				header('location: index.php');
				} 
				else {
				echo "<script type= 'text/javascript'>alert('Error: " . $sql . "<br>" . $conn->error."');</script>";
				header('location: signup.php');
				}
		     	$last_row = mysqli_insert_id($conn);
			$conn->close();
			}

		else{
			echo "<script>alert('Passwords Do not Match'); window.location.href='./signup.php';</script>";
		}
	
}
}
?>

<HTML>
<BODY>
Success!
</BODY>
</HTML>
