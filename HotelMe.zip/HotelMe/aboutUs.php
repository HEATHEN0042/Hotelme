<HTML>
<HEAD>
<link rel="stylesheet" href="./css/hotelme.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="./photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="./photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="index.php">Home</a></li>
<li><a href="aboutUs.php">About Us</a></li>
<li><a href="contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="index.php">Login</a></li>
<li></li>
<li></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="aboutus">
	<div id="aboutUsText">
	<h1 id = "aboutUsTitle"> Adventure is a Click Away</h1>
	<p>
	 We are an online booking agency for hotel rooms. We strive to provide a quick and easy service to all of out customers.You must have a valid 
         account with us in order to view our deals, available rooms, and make reservations. If you already have an account, please feel free to sign in to use the home page, 
         or the browse page to place any reservations. If you do not have an account, please navigate to the sign up page and create an account. Your satisfaction is our number 
         one priority. If you have any further questions please feel free to contact us using the information given on the contact us page.
         We would like to thank you for visiting our site, and remember your adventure is just a few clicks away! 
	</p>
	</div>
</div>