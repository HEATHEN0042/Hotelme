<?php
include('checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../index.php');
}
?>


<HTML>
<HEAD>
<link rel="stylesheet" href="./css/checkout.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="./photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id="logopic">
</div>

<div id="nav">
<ul id="left">
<li><a href="home.php">Home</a></li>
<li><a href="aboutUs.php">About Us</a></li>
<li><a href="currentDeals.php">Current Deals</a></li>
<li><a href="giftCards.php">Gift Cards</a></li>
<li><a href="browse.php">Browse Rooms</a></li>
<li><a href="contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="logout.php">Logout</a></li>
<li><a href="shoppingCart.php">Shopping Cart</a></li>
<li><a href="myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="HomeImage">
<form id="login" action="checkoutInsert.php"  method="POST">
Cardholder Name:<br>
<input type="text" name="cardname" size="auto"><br>
Credit Card Number:<br>
<input type="text" name="cardnumber" size="auto"><br>
Expiration Date:<br>
<input type="Date" name="expdate" size="auto"><br>
CVC:<br>
<input type="text" name="cvc" size="auto"><br>
<input type="submit" value="Submit Payment" name="submitpayment">
</form>
</div>

</BODY>
</HTML>

