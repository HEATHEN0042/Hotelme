<?php
include('checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../index.php');
}
?>

<?php
include('checklogin.php');

$hostname = "naplesbait.com";
$username = "hmservice";
$password = "service";
$dbname = "hotelme";
$conn = new mysqli($hostname,$username,$password,$dbname);

if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

?>

<HTML>
<HEAD>
<link rel="stylesheet" href="./css/shoppingCart.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="./photos/hotelme3.png"alt="logo" style="width:200px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="./photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="home.php">Home</a></li>
<li><a href="aboutUs.php">About Us</a></li>
<li><a href="currentDeals.php">Current Deals</a></li>
<li><a href="giftCards.php">Gift Cards</a></li>
<li><a href="browse.php">Browse Rooms</a></li>
<li><a href="contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="logout.php">Logout</a></li>
<li><a href="shoppingCart.php">Shopping Cart</a></li>
<li><a href="myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>



<div id="aboutus">
<table id="results" align="center">
<?php
$sql = "SELECT * FROM Cart WHERE Email='{$_SESSION['login_user']}'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    // output data of each row
    while($row = $result->fetch_assoc()) {
?>
        <br>
        <tr>
        <td>  Item: <?php echo $row["Item"]; ?></td>
        <td>  Hotel ID: <?php echo $row["HotelID"]; ?></td> 
        <td>  Room ID: <?php echo $row["RoomID"]; ?></td>
        <td>  Start Date: <?php echo $row["StartDate"]; ?></td>
        <td>  End Dates: <?php echo $row["EndDate"]; ?></td>
        <td>  First Name:<?php echo $row["recipFN"]; ?></td>
        <td>  Last Name:<?php echo $row["recipLN"]; ?></td>
        <td>  Price: $<?php echo $row["Price"]; ?></td>
        <td><form action="rowDel.php" method="POST">
        <input type="hidden" name="cartNo" value="<?php echo $row["cartNo"];?>">
        <input type="Submit" value="Remove" name="rowdel"></form></td>   
        </tr>
        
<?php

$total+=$row["Price"];
    }
}

?>
 
</table>
Total: $<?php echo $total; ?><br>
<input type="button" value="Checkout" Onclick="window.location.href='checkout.php'">
</div>
</BODY>
</HTML>


