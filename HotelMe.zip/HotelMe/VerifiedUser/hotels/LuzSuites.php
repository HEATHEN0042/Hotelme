<?php
include('../checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="../css/hotelPage.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="../photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="../photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="../home.php">Home</a></li>
<li><a href="../aboutUs.php">About Us</a></li>
<li><a href="../currentDeals.php">Current Deals</a></li>
<li><a href="../giftCards.php">Gift Cards</a></li>
<li><a href="../browse.php">Browse Rooms</a></li>
<li><a href="../contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="../logout.php">Logout</a></li>
<li><a href="../shoppingCart.php">Shopping Cart</a></li>
<li><a href="../myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="mainPage">
<h1>Luz Suites</h1>
<img src="./photos/hotel14.jpg"alt="Luz Suites" style="width:50%;height:37.5%;" id = "hotelImage"><br>
<br>
<p>
Come and join us at our one of a kind resort. Experience a family friendly luxury stay. Our hotels come equipped with plenty of amenities to make sure you enjoy your stay. This coupled with friendly staff helps us ensure a life long relationship with all of our guests.  
</p><br>
<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d106217.62552248116!2d-84.48361805591334!3d33.70116468856554!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e6!4m5!1s0x88f4fd2fe1035901%3A0x4117a3ef1892b048!2sHartsfield-Jackson+Atlanta+International+Airport%2C+6000+N+Terminal+Pkwy%2C+Atlanta%2C+GA+30320!3m2!1d33.6407282!2d-84.4277001!4m5!1s0x88f50479d68818c3%3A0x2f68c1d03932d2dd!2sAtlanta+Marriott+Marquis%2C+265+Peachtree+Center+Ave+NE%2C+Atlanta%2C+GA+30303!3m2!1d33.7615847!2d-84.3856145!5e0!3m2!1sen!2sus!4v1489372452358" width="50%" height="37.5%" frameborder="0" style="border:0" allowfullscreen></iframe>

<form action="../globalSessions.php" method="POST">
<input type="hidden" name="HotelId" value="2">
<input type="hidden" name="city" value="atlanta">
<input type="submit" name="hotelSubmit" value="Book Now" style="margin-top:2%;">
</form>
</div>
<script src="//www.powr.io/powr.js" external-type="godaddy"></script> 
 <div class="powr-reviews" id="42bfbb7f_1489434005438"></div>