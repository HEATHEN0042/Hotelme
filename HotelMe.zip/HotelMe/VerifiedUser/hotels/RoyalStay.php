<?php
include('../checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="../css/hotelPage.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="../photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="../photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>


<div id="nav">
<ul id="left">
<li><a href="../home.php">Home</a></li>
<li><a href="../aboutUs.php">About Us</a></li>
<li><a href="../currentDeals.php">Current Deals</a></li>
<li><a href="../giftCards.php">Gift Cards</a></li>
<li><a href="../browse.php">Browse Rooms</a></li>
<li><a href="../contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="../logout.php">Logout</a></li>
<li><a href="../shoppingCart.php">Shopping Cart</a></li>
<li><a href="../myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="mainPage">
<h1>Royal Stay</h1>
<img src="./photos/hotel17.jpg"alt="Royal Stay" style="width:50%;height:37.5%;" id = "hotelImage"><br>
<br>
<p>
Come and join us at our one of a kind resort. Experience a family friendly luxury stay. Our hotels come equipped with plenty of amenities to make sure you enjoy your stay. This coupled with friendly staff helps us ensure a life long relationship with all of our guests.  
</p><br>
<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d26604.49646982796!2d-86.79666209902548!3d33.53877021790308!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e6!4m5!1s0x88891aa4f6775025%3A0x9326a00858ed2b68!2sBirmingham-Shuttlesworth+International+Airport%2C+Messer+Airport+Highway%2C+Birmingham%2C+AL!3m2!1d33.5624269!2d-86.754126!4m5!1s0x88891b973a9cda7d%3A0x91a2f7b84ba97f5c!2s2101+5th+Ave+N%2C+Birmingham%2C+AL+35203!3m2!1d33.5187236!2d-86.8063865!5e0!3m2!1sen!2sus!4v1489372835673" width="50%" height="37.5%" frameborder="0" style="border:0" allowfullscreen></iframe>

<form action="../globalSessions.php" method="POST">
<input type="hidden" name="HotelId" value="3">
<input type="hidden" name="city" value="birmingham">
<input type="submit" name="hotelSubmit" value="Book Now" style="margin-top:2%;">
</form>
</div>
<script src="//www.powr.io/powr.js" external-type="godaddy"></script> 
 <div class="powr-reviews" id="42bfbb7f_1489434005438"></div>