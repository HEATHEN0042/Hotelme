<?php
include('../checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="../css/hotelPage.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="../photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="../photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="../home.php">Home</a></li>
<li><a href="../aboutUs.php">About Us</a></li>
<li><a href="../currentDeals.php">Current Deals</a></li>
<li><a href="../giftCards.php">Gift Cards</a></li>
<li><a href="../browse.php">Browse Rooms</a></li>
<li><a href="../contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="../logout.php">Logout</a></li>
<li><a href="../shoppingCart.php">Shopping Cart</a></li>
<li><a href="../myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="mainPage">
<h1>Hide Away Resort</h1>
<img src="./photos/hotel12.jpg"alt="Hide Away Resort" style="width:50%;height:37.5%;" id = "hotelImage"><br>
<br>
<p>
Come and join us at our one of a kind resort. Experience a family friendly luxury stay. Our hotels come equipped with plenty of amenities to make sure you enjoy your stay. This coupled with friendly staff helps us ensure a life long relationship with all of our guests.  
</p><br>
<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d26632.264397905034!2d-112.02853204917129!3d33.4484454695519!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e6!4m5!1s0x872b0e5c330370a5%3A0x82f535d5e256ee42!2sPHOENIX+airport%2C+East+Sky+Harbor+Boulevard%2C+Phoenix%2C+AZ!3m2!1d33.437268599999996!2d-112.0077881!4m5!1s0x872b0e84de6a63af%3A0xf0688469665ff285!2s320+N+44th+St%2C+Phoenix%2C+AZ+85008!3m2!1d33.4518249!2d-111.9888002!5e0!3m2!1sen!2sus!4v1489372001517" width="50%" height="37.5%" frameborder="0" style="border:0" allowfullscreen></iframe>

<form action="../globalSessions.php" method="POST">
<input type="hidden" name="HotelId" value="16">
<input type="hidden" name="city" value="pheonix">
<input type="submit" name="hotelSubmit" value="Book Now" style="margin-top:2%;">
</form>
</div>
<script src="//www.powr.io/powr.js" external-type="godaddy"></script> 
 <div class="powr-reviews" id="42bfbb7f_1489434005438"></div>