<?php
include('../checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="../css/hotelPage.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="../photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="../photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="../home.php">Home</a></li>
<li><a href="../aboutUs.php">About Us</a></li>
<li><a href="../currentDeals.php">Current Deals</a></li>
<li><a href="../giftCards.php">Gift Cards</a></li>
<li><a href="../browse.php">Browse Rooms</a></li>
<li><a href="../contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="../logout.php">Logout</a></li>
<li><a href="../shoppingCart.php">Shopping Cart</a></li>
<li><a href="../myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="mainPage">
<h1>Eagles Nest</h1>
<img src="./photos/hotel7.jpg"alt="Eagles Nest" style="width:50%;height:37.5%;" id = "hotelImage"><br>
<br>
<p>
Come and join us at our one of a kind resort. Experience a family friendly luxury stay. Our hotels come equipped with plenty of amenities to make sure you enjoy your stay. This coupled with friendly staff helps us ensure a life long relationship with all of our guests.  
</p><br>
<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d188915.87392348333!2d-83.53919560522192!3d42.28256771163609!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e6!4m5!1s0x883b4f5ddaf0b305%3A0x2341c0cf25bf98fb!2sDetroit+Metropolitan+Wayne+County+Airport%2C+Detroit%2C+MI+48242!3m2!1d42.216172199999995!2d-83.3553842!4m5!1s0x8824d29c95485b03%3A0x2a939ee0d22dcde8!2s3071+W+Grand+Blvd%2C+Detroit%2C+MI+48202!3m2!1d42.3701243!2d-83.0749811!5e0!3m2!1sen!2sus!4v1489370783257" width="50%" height="37.5%" frameborder="0" style="border:0" allowfullscreen></iframe>

<form action="../globalSessions.php" method="POST">
<input type="hidden" name="HotelId" value="11">
<input type="hidden" name="city" value="detroit">
<input type="submit" name="hotelSubmit" value="Book Now" style="margin-top:2%;">
</form>
</div>

<script src="//www.powr.io/powr.js" external-type="godaddy"></script> 
 <div class="powr-reviews" id="42bfbb7f_1489434005438"></div>