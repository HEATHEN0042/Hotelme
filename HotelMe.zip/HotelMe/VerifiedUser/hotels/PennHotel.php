<?php
include('../checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="../css/hotelPage.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="../photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="../photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="../home.php">Home</a></li>
<li><a href="../aboutUs.php">About Us</a></li>
<li><a href="../currentDeals.php">Current Deals</a></li>
<li><a href="../giftCards.php">Gift Cards</a></li>
<li><a href="../browse.php">Browse Rooms</a></li>
<li><a href="../contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="../logout.php">Logout</a></li>
<li><a href="../shoppingCart.php">Shopping Cart</a></li>
<li><a href="../myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="mainPage">
<h1>Penn Hotel</h1>
<img src="./photos/hotel16.jpg"alt="Penn Hotel" style="width:50%;height:37.5%;" id = "hotelImage"><br>
<br>
<p>
Come and join us at our one of a kind resort. Experience a family friendly luxury stay. Our hotels come equipped with plenty of amenities to make sure you enjoy your stay. This coupled with friendly staff helps us ensure a life long relationship with all of our guests.  
</p><br>
<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d26805.991705009517!2d-80.0432497500835!3d32.878360830240254!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e6!4m5!1s0x88fe630f4bea2aa3%3A0x1c4bc7d09feefedf!2sCharleston+International+Airport%2C+5500+International+Blvd%2C+Charleston%2C+SC+29418!3m2!1d32.8942676!2d-80.038159!4m5!1s0x88fe63512d82ab8f%3A0x3b7c67aecb97695e!2s5055+International+Blvd%2C+North+Charleston%2C+SC!3m2!1d32.866670899999995!2d-80.01454149999999!5e0!3m2!1sen!2sus!4v1489372715532" width="50%" height="37.5%" frameborder="0" style="border:0" allowfullscreen></iframe>

<form action="../globalSessions.php" method="POST">
<input type="hidden" name="HotelId" value="5">
<input type="hidden" name="city" value="charleston">
<input type="submit" name="hotelSubmit" value="Book Now" style="margin-top:2%;">
</form>
</div>
<script src="//www.powr.io/powr.js" external-type="godaddy"></script> 
 <div class="powr-reviews" id="42bfbb7f_1489434005438"></div>