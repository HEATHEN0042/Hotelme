<?php
include('checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../index.php');
}
?>
<?php
session_start();

include('checklogin.php');

$hostname = "naplesbait.com";
$username = "hmservice";
$password = "service";
$dbname = "hotelme";
$conn = new mysqli($hostname,$username,$password,$dbname);

/*Variables posted From Browse.php*/
$type=$_POST['filterType'];
$filterVar=$_POST['filterVar'];
/*Session Varibles*/
$_SESSION['type']=$type;
$_SESSION['filterVar']=$filterVar;
$_SESSION['pageSubmit']=FALSE;
$typeCheck= $_SESSION['type'];
$sql = $_SESSION['sql']; 
$result = $conn->query($sql);
      
       if(empty($_POST['filterSubmit'])){
       $_SESSION['sql']="Select * From Hotels";
       }
       
       if(isset($_POST['filterSubmit'])){
       
       $_SESSION['pageSubmit']=TRUE;

       }
	
	
       if ($_SESSION['pageSubmit'] && $_SESSION['filterVar']){
	
		
                if($_SESSION['type']=='City'){
                        echo '<script type="text/javascript"> alert("Location Case"); </script>';
                        
                        $_SESSION['sql'] = "SELECT * FROM Hotels WHERE City='".$_SESSION['filterVar']."'";                                                                   
                        header('location: browse.php');
                }
                else if($_SESSION['type']=='GuestNum'){
                        echo '<script type="text/javascript"> alert("Location Case"); </script>';
                        
                        $_SESSION['sql'] = "SELECT DISTINCT Name,StreetAddress,City,Zip,URL FROM Hotels INNER JOIN Rooms ON Hotels.HotelID=Rooms.HotelID WHERE MaxOcc='".$_SESSION['filterVar']."'";                                                                   
                        header('location: browse.php');
		}
                else if($_SESSION['type']=='NumOfRooms'){
                        echo '<script type="text/javascript"> alert("Location Case"); </script>';
                        
                        $_SESSION['sql'] = "SELECT Distinct Name,StreetAddress,City,Zip,URL,Rooms.HotelID,Count(Rooms.HotelID) AS RoomCount FROM Hotels INNER JOIN Rooms ON Hotels.HotelID=Rooms.HotelID Group BY HotelID HAVING RoomCount='".$_SESSION['filterVar']."'";                                                                 
                        header('location: browse.php');
		}
		
		else if($_SESSION['type']=='CheckInDate'){
		 $_SESSION['sql'] ="SELECT Distinct Name,StreetAddress,City,Zip,URL,Hotels.HotelID FROM Hotels INNER JOIN OrderHistory ON Hotels.HotelID=OrderHistory.HotelID WHERE NOT StartDate='".$_SESSION['filterVar']."'";
		header('location: browse.php');
		}
               	else if($_SESSION['type']=='CheckOutDate'){
		 $_SESSION['sql'] ="SELECT Distinct Name,StreetAddress,City,Zip,URL,Hotels.HotelID FROM Hotels INNER JOIN OrderHistory ON Hotels.HotelID=OrderHistory.HotelID WHERE NOT EndDate='".$_SESSION['filterVar']."'";
		header('location: browse.php');
		}
	
	}
	elseif($_SESSION['pageSubmit'] && $_SESSION['filterVar']==""){
	$_SESSION['sql']="Select * From Hotels";
	header('location: browse.php');
	}

	 

?>