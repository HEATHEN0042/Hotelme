<?php
include('checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../index.php');
}
?>

<?php 
$hostname = "naplesbait.com";
$username = "hmservice";
$password = "service";
$dbname = "hotelme";
$conn = new mysqli($hostname,$username,$password,$dbname);

if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
?>


<?php
$HotelID = $_POST(['HotelID']);
$Price = $_POST(['Price']);
$RoomID = $_POST(['RoomID']);
$Dates = $_POST(['Dates']);
$recipFN = $_POST(['recipFN']);
$recipFN = $_POST(['recipLN']);
$Item = "Gift Card";
if (isset($_POST["addToCart"])) {
$sql = "INSERT INTO Cart(Item,Price,HotelID,RoomID,Dates,recipFN,recipLN,Email)VALUES('$Item','$Price','$HotelID','$RoomID','$Dates','$recipFN','$recipLN','{$_SESSION['login_user']}')";

if ($conn->query($sql) === TRUE) {
header('location: shoppingCart.php');
} 
else {
header('location: giftCards.php');
}

$conn->close();
}

?>