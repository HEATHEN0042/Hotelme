<?php
include('checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../index.php');
}






if(isset($_POST['submitpayment'])) {

$cardname=$_POST['cardname'];
$cardnumber=$_POST['cardnumber'];
$expdate=$_POST['expdate'];
$cvc=$_POST['cvc'];
 
if(is_numeric($cardname)){
echo "<script>alert('Enter A Valid Cardholder Name'); window.location.href='./checkout.php';</script>";
}

elseif(!is_numeric($cardnumber)||strlen($cardnumber) != 16){
echo "<script>alert('Enter A Valid Card Number'); window.location.href='./checkout.php';</script>";
}

elseif(!is_numeric($cvc)){
echo "<script>alert('Enter A Valid CVC Code'); window.location.href='./checkout.php';</script>";
}

else{

	$sql="INSERT INTO GiftCard(Price,recipFN,recipLN) SELECT Price,recipFN,recipLN FROM Cart WHERE Email='{$_SESSION['login_user']}'";

	
        $sql2="INSERT INTO OrderHistory(Email,HotelID,RoomNumber,StartDate,EndDate,Price,recipFN,recipLN) SELECT Email,HotelID,RoomNumber,StartDate,EndDate,Price,recipFN,recipLN FROM Cart WHERE Email='{$_SESSION['login_user']}'";
         
        $sql3="Update  OrderHistory SET CardholderName='$cardname',CardNumber='$cardnumber',ExpirationDate='$expdate',CVC='$cvc' WHERE Email='{$_SESSION['login_user']}'AND CardNumber IS NULL";

        $sql4="INSERT INTO OrderList(Email)VALUES('{$_SESSION['login_user']}')";

          if($conn->query($sql2)===TRUE && $conn->query($sql3)===TRUE && $conn->query($sql4)===TRUE) {
			header('location: invoice.php');
		}
 
		else {
			header('location: shoppingCart.php');
		}

		$conn->close();
	}
}
?>

