<?php 
$hostname = "naplesbait.com";
$username = "hmservice";
$password = "service";
$dbname = "hotelme";
$conn = new mysqli($hostname,$username,$password,$dbname);

if(isset($_POST["rowdel"])){

$cartNo=$_POST["cartNo"];
echo $cartNo;
$sqlDel="DELETE FROM Cart WHERE cartNo='$cartNo'";

if($conn->query($sqlDel)===TRUE){
header('location: shoppingCart.php');
}
}
?>