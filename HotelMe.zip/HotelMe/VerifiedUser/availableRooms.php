<?php
include('checklogin.php');


if (empty($_SESSION['login_user'])) {
    header('Location: ../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="./css/availableRooms.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="./photos/hotelme3.png"alt="logo" style="width:200px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="./photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="home.php">Home</a></li>
<li><a href="aboutUs.php">About Us</a></li>
<li><a href="currentDeals.php">Current Deals</a></li>
<li><a href="giftCards.php">Gift Cards</a></li>
<li><a href="browse.php">Browse Rooms</a></li>
<li><a href="contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="logout.php">Logout</a></li>
<li><a href="shoppingCart.php">Shopping Cart</a></li>
<li><a href="myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="aboutus">

<div id="filter">

<form id="filterform" action="selectRoom.php" method="POST">
  Start Date: <input type="date" name="filterVar1">
  End Date: <input type="date"  name="filterVar2">
  Room Number: <input type="text" name="filterVar3">
  <input type="submit" name="roomSubmit" value="Add To Cart">
</form>
</div>


<table id="results" align="center">
<?php
include('selectRoom.php');

if ($result->num_rows > 0) {

    // output data of each row
    while($row = $result->fetch_assoc()) {
?>
        <tr>
        <td>Room Number:<?php echo $row["RoomNumber"]; ?></td>
        <td>Max Occupants: <?php echo $row["MaxOcc"]; ?></td> 
        <td>Price Per Night: <?php echo $row["Price"]; ?></td>
        </tr>
        
<?php
    }
}
$conn->close();
?>

</table>
</div>
</BODY>
</HTML>

