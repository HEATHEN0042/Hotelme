<?php 
$hostname = "naplesbait.com";
$username = "hmservice";
$password = "service";
$dbname = "hotelme";
$conn = new mysqli($hostname,$username,$password,$dbname);

if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
?>
<?php
session_start(); // Starting Session
$error=" "; // Variable To Store Error Message
if (isset($_POST['submit'])) {
	if (empty($_POST['email']) || empty($_POST['password'])) {
	$error = "Username or Password is invalid";
        header('location: ../index.php');
}
else
{
// Define $username and $password
$email=$_POST['email'];
$password=$_POST['password'];
// SQL query to fetch information of registerd users and finds user match.
$sql ="select * from Customers where Password='$password' AND Email='$email'";

if ($conn->query($sql)) {
echo "<script type= 'text/javascript'>alert('Login Query successfully');</script>";
}
 
else{
echo "<script type= 'text/javascript'>alert('Login Query Failed');</script>";
}

$result = mysqli_query($conn,$sql);
$rows = mysqli_num_rows($result);


if ($rows == 1) {
$_SESSION['login_user']=$email; // Initializing Session
header('location: home.php'); // Redirecting To Other Page
} else {
$error = "Username or Password is invalid";
header('location: ../index.php');
}
$conn->close(); // Closing Connection
}
}
?>