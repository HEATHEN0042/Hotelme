<?php
include('checklogin.php');
Session_Start(); 
unset($_SESSION["login_user"]);
header('location:../index.php');
?>