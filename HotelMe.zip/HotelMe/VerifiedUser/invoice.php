<?php
include('./checklogin.php');
 
$hostname = "naplesbait.com";
$username = "hmservice";
$password = "service";
$dbname = "hotelme";
$conn = new mysqli($hostname,$username,$password,$dbname);

if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}


$sql1="SELECT * FROM Customers WHERE Email='{$_SESSION['login_user']}'";
$result1 = $conn->query($sql1);
if ($result1->num_rows > 0) {

    while($userInfo = $result1->fetch_assoc()) {
    $FName= $userInfo["FName"];
    $LName= $userInfo["LName"]; 
    $StreetAddress= $userInfo["StreetAddress"];
    $City= $userInfo["City"];
    $State= $userInfo["State"];
    $Zip= $userInfo["Zip"];
    }
}
?>

<HTML>
<BODY>
<h1>HOTEL ME INVOICE</h1>

TO:
First Name:<?php echo $FName ?><br>
Last Name:<?php echo $LName ?><br>
StreetAddress:<?php echo $StreetAddress  ?><br>
City:<?php echo $City ?><br>
State:<?php echo $State ?><br>
Zip:<?php echo $Zip ?><br>

<table id="results" align="center">
<?php

$sql= "SELECT * FROM Cart WHERE Email='{$_SESSION['login_user']}'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    // output data of each row
    while($row = $result->fetch_assoc()) {
?>
        <tr> 
        <td>Item: <?php echo $row["Item"]; ?></td>
        <td>Hotel Id: <?php echo $row["HotelID"]; ?></td> 
        <td>Room Number: <?php echo $row["RoomNumber"]; ?></td>
        <td>Start Date: <?php echo $row["StartDate"]; ?></td>
        <td>End Dates: <?php echo $row["EndDate"]; ?></td>
        <td>First Name:<?php echo $row["recipFN"]; ?></td>
        <td>Last Name:<?php echo $row["recipLN"]; ?></td>
        <td>Stay Total: $<?php echo $row["Price"]; ?></td>
        </tr>
        
<?php
    $Total+=$row["Price"]; 
    }
}
$conn->close();
?>
Order Total: $<?php echo $Total;?><br>
<form action="" method="POST">
<input type="Submit" Name="Continue" Value="Continue">
</form>
<?php
include('checklogin.php');
include('globalSessions.php');

if(isset($_POST['Continue'])){

$cartDel="DELETE FROM Cart WHERE Email='{$_SESSION['login_user']}'";


if($conn->query($cartDel)===True){
    
    if(empty($_SESSION['City'])){
       header('location:home.php');
    }
    else{
    header('location: ./attractions/'.$_SESSION['City'].'.php');
    }
}
else{
header('location: invoice.php');
}
}
?>

</table>
</BODY>
</HTML>