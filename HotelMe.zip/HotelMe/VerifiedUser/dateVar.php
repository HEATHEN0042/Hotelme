<?php
Session_Start();
if(isset($_POST['viewOrder'])){

$_SESSION['pdate'] = $_POST['purchaseDate'];

header('location:./orderFilter.php');
}
?>