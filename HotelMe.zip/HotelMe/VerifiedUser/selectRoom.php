<?php
include('checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../index.php');
}
?>
<?php
session_start();
include('checklogin.php');
include('globalSessions.php');

$hostname = "naplesbait.com";
$username = "hmservice";
$password = "service";
$dbname = "hotelme";
$conn = new mysqli($hostname,$username,$password,$dbname);

/*Variables posted From Browse.php*/
$type=$_POST['filterType'];
$filterVar1=$_POST['filterVar1'];
$filterVar2=$_POST['filterVar2'];
$filterVar3=$_POST['filterVar3'];
$date1=strtotime($filterVar1);
$date2=strtotime($filterVar2);
$difference=$date1-$date2;
$days=$difference/(60*60*24);
/*Session Varibles*/
$_SESSION['type']=$type;
$_SESSION['filterVar1']=$filterVar1;
$_SESSION['filterVar2']=$filterVar2;
$_SESSION['filterVar3']=$filterVar3;
$_SESSION['pageSubmit']=FALSE;


$typeCheck= $_SESSION['type'];
$sql = "Select * From Rooms Where HotelId='".$_SESSION['HotelId']."'";
$result = $conn->query($sql);
      
if(isset($_POST['roomSubmit'])){

$sql2 = "Select * From OrderHistory WHERE RoomNumber='$filterVar3' AND StartDate='$filterVar1' AND EndDate='$filterVar2'";
$check = $conn->query($sql2);
$checkrows = mysqli_num_rows($check);

if ($checkrows == 1) {
echo "Room Unavailable For That Date. Try another room or different Date.";
} 
else {

$sqlPrice="SELECT Price FROM Rooms WHERE HotelID='".$_SESSION['HotelId']."' AND RoomNumber='$filterVar3'";
$rooms=$conn->query($sqlPrice);
$roomAss=mysqli_fetch_array($rooms);
$roomPrice=floatval($roomAss["Price"]);
$linetotal=-1*$days*$roomPrice;

$recipFN="";
$recipLN="";
$Item="Hotel Room";
$sql3= "INSERT INTO Cart(Item,Price,HotelID,RoomNumber,StartDate,EndDate,recipFN,recipLN,Email)VALUES('$Item','$linetotal','{$_SESSION['HotelId']}','{$_SESSION['filterVar3']}','{$_SESSION['filterVar1']}','{$_SESSION['filterVar2']}','$recipFN','$recipLN','{$_SESSION['login_user']}')";
if ($conn->query($sql3) === TRUE) {
header('location: shoppingCart.php');
} 
else {
header('location: availableRooms.php');
}

}       

}      
       
       
       
       
	

?>