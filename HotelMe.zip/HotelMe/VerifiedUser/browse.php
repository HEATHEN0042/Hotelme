<?php
include('checklogin.php');


if (empty($_SESSION['login_user'])) {
    header('Location: ../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="./css/browser.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="./photos/hotelme3.png"alt="logo" style="width:200px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="./photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="home.php">Home</a></li>
<li><a href="aboutUs.php">About Us</a></li>
<li><a href="currentDeals.php">Current Deals</a></li>
<li><a href="giftCards.php">Gift Cards</a></li>
<li><a href="browse.php">Browse Rooms</a></li>
<li><a href="contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="logout.php">Logout</a></li>
<li><a href="shoppingCart.php">Shopping Cart</a></li>
<li><a href="myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="aboutus">

<div id="filter">

<form id="filterform" action="browsefilter.php" method="post">
  <input type="radio" name="filterType" value="City">Location
  <input type="radio" name="filterType" value="GuestNum">Number Of Guests
  <input type="radio" name="filterType" value="NumOfRooms">Number Of Rooms
  <input type="radio" name="filterType" value="CheckInDate">Check-In Date
  <input type="radio" name="filterType" value="CheckOutDate">Checkout Date
  <input type="text"  name="filterVar">
  <input type="submit" name="filterSubmit" value="Submit">
</form>
</div>


<table id="results" align="center">
<?php
include('browsefilter.php');

if ($result->num_rows > 0) {

    // output data of each row
    while($row = $result->fetch_assoc()) {
?>
        <tr>
        <td>Name: <?php echo $row["Name"]; ?></td>
        <td>Address: <?php echo $row["StreetAddress"]; ?></td> 
        <td>City: <?php echo $row["City"]; ?></td>
        <td>Zip: <?php echo $row["Zip"]; ?></td>
        <td><a href='<?php echo $row["URL"];?>'><input type="button" value="View"</a></td>
        </tr>
        
<?php
    }
}
$conn->close();
?>

</table>
</div>
</BODY>
</HTML>

