<?php
include('../checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="../css/attractions.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="../photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="../photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="../home.php">Home</a></li>
<li><a href="../aboutUs.php">About Us</a></li>
<li><a href="../currentDeals.php">Current Deals</a></li>
<li><a href="../giftCards.php">Gift Cards</a></li>
<li><a href="../browse.php">Browse Rooms</a></li>
<li><a href="../contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="../logout.php">Logout</a></li>
<li><a href="../shoppingCart.php">Shopping Cart</a></li>
<li><a href="../myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="aboutus">
	<div id="aboutUsText">
	<h1 id = "aboutUsTitle">Santa Fe Attractions</h1>
<br>Museum of International Folk Art(Click <a href="https://www.tripadvisor.com/Attraction_Review-g60958-d135699-Reviews-Museum_of_International_Folk_Art-Santa_Fe_New_Mexico.html">HERE</a> for more info) 
<br><br>Santa Fe Opera House(Click <a href="https://www.tripadvisor.com/Attraction_Review-g60958-d107440-Reviews-Santa_Fe_Opera_House-Santa_Fe_New_Mexico.html">HERE</a> for more info)
<br><br>The Cathedral Basilica of St Francis of Assisi(Click <a href="https://www.tripadvisor.com/Attraction_Review-g60958-d123657-Reviews-The_Cathedral_Basilica_of_St_Francis_of_Assisi-Santa_Fe_New_Mexico.html">HERE</a> for more info) 
	</div>
</div>