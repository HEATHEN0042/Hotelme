<?php
include('../checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="../css/attractions.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="../photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="../photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="../home.php">Home</a></li>
<li><a href="../aboutUs.php">About Us</a></li>
<li><a href="../currentDeals.php">Current Deals</a></li>
<li><a href="../giftCards.php">Gift Cards</a></li>
<li><a href="../browse.php">Browse Rooms</a></li>
<li><a href="../contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="../logout.php">Logout</a></li>
<li><a href="../shoppingCart.php">Shopping Cart</a></li>
<li><a href="../myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="aboutus">
	<div id="aboutUsText">
	<h1 id = "aboutUsTitle">Jackson Attractions</h1>
<br>Mississippi Children's Museum(Click <a href="https://www.tripadvisor.com/Attraction_Review-g43833-d2010240-Reviews-Mississippi_Children_s_Museum-Jackson_Mississippi.html">HERE</a> for more info) 
<br><br>Mississippi Museum of Natural Science(Click <a href="https://www.tripadvisor.com/Attraction_Review-g43833-d109484-Reviews-Mississippi_Museum_of_Natural_Science-Jackson_Mississippi.html">HERE</a> for more info)
<br><br>State Capitol(Click <a href="https://www.tripadvisor.com/Attraction_Review-g43833-d105887-Reviews-State_Capitol-Jackson_Mississippi.html">HERE</a> for more info) 
	
	</div>
</div>