<?php
include('../checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="../css/attractions.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="../photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="../photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="../home.php">Home</a></li>
<li><a href="../aboutUs.php">About Us</a></li>
<li><a href="../currentDeals.php">Current Deals</a></li>
<li><a href="../giftCards.php">Gift Cards</a></li>
<li><a href="../browse.php">Browse Rooms</a></li>
<li><a href="../contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="../logout.php">Logout</a></li>
<li><a href="../shoppingCart.php">Shopping Cart</a></li>
<li><a href="../myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="aboutus">
	<div id="aboutUsText">
	<h1 id = "aboutUsTitle">Tampa Attractions</h1>
<br>Busch Gardens(Click <a href="https://www.tripadvisor.com/Attraction_Review-g34678-d107648-Reviews-Busch_Gardens_Tampa-Tampa_Florida.html">HERE</a> for more info) 
<br><br>Sunshine Skyway Bridge(Click <a href="https://www.tripadvisor.com/Attraction_Review-g34678-d1774688-Reviews-Sunshine_Skyway_Bridge-Tampa_Florida.html">HERE</a> for more info)
<br><br>Tampa Theater(Click <a href="https://www.tripadvisor.com/Attraction_Review-g34678-d284859-Reviews-Tampa_Theatre-Tampa_Florida.html">HERE</a> for more info) 
	</div>
</div>