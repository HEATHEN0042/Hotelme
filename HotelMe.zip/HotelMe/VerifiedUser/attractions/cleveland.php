<?php
include('../checklogin.php');

if (empty($_SESSION['login_user'])) {
    header('Location: ../../index.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="../css/attractions.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="../photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="../photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="../home.php">Home</a></li>
<li><a href="../aboutUs.php">About Us</a></li>
<li><a href="../currentDeals.php">Current Deals</a></li>
<li><a href="../giftCards.php">Gift Cards</a></li>
<li><a href="../browse.php">Browse Rooms</a></li>
<li><a href="../contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="../logout.php">Logout</a></li>
<li><a href="../shoppingCart.php">Shopping Cart</a></li>
<li><a href="../myAccount.php">My Account</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="aboutus">
	<div id="aboutUsText">
	<h1 id = "aboutUsTitle">Cleveland Attractions</h1>
<br>Cleveland Museum of Art(Click <a href="https://www.tripadvisor.com/Attraction_Review-g50207-d137616-Reviews-Cleveland_Museum_of_Art-Cleveland_Ohio.html">HERE</a> for more info) 
<br><br>Cleveland Orchestra at Severance Hall (Click <a href="https://www.tripadvisor.com/Attraction_Review-g50207-d527048-Reviews-Cleveland_Orchestra_at_Severance_Hall-Cleveland_Ohio.html">HERE</a> for more info)
<br><br>West Side Market(Click <a href="https://www.tripadvisor.com/Attraction_Review-g50207-d272156-Reviews-West_Side_Market-Cleveland_Ohio.html">HERE</a> for more info) 
	
	</div>
</div>