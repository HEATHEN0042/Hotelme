<?php
include('./VerfiedUser/checklogin.php');
Session_Start();
if (isset($_SESSION['login_user'])) {
    header('Location: ./VerifiedUser/home.php');
}
?>

<HTML>
<HEAD>
<link rel="stylesheet" href="./css/index.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>
<div id="logo">
<img src="./photos/hotelme3.png"alt="logo" style="width:250px;height:100px;" id="logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="./photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>




<div id="nav">
<ul id="left">
<li><a href="index.php">Home</a></li>
<li><a href="aboutUs.php">About Us</a></li>
<li><a href="contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
</ul>
</div>

<div id="headerBreak"></div>

<div id="HomeImage">
<form id="login" action="./VerifiedUser/checklogin.php" method="post">
Login to Get Started!<br>
Email:<br>
<input type="text" name="email" size="auto"><br>
Password:<br>
<input type="password" name="password" size="auto"><br>
<input type="submit" value="Submit" name="submit">
<input type="button" value="Sign Up" Onclick="window.location.href='signup.php'">
</form>
</div>

</BODY>
</HTML>

