<HTML>
<HEAD>
<link rel="stylesheet" href="./css/signup.css">
<TITLE>Hotel Me</TITLE>
</HEAD>

<BODY>

<div id="logo">
<img src="./photos/hotelme3.png"alt="logo" style="width:200px;height:100px;" id = "logopic">
<a href="https://www.facebook.com/OfficialHotelMe/"><img src="./photos/fbicon.png" alt="fb" style="width:50px;height:50px;" id="fbicon"></a>
</div>

<div id="nav">
<ul id="left">
<li><a href="index.php">Home</a></li>
<li><a href="aboutUs.php">About Us</a></li>
<li><a href="currentDeals.php">Current Deals</a></li>
<li><a href="contactUs.php">Contact Us</a></li>
</ul>
<ul id="right">
<li><a href="shoppingCart.php">Shopping Cart</a></li>
<li><a href="myAccount.php">My Account</a></li>
<li><a href="signup.php">Sign Up</a></li>
</ul>
</div>

<div id="headerBreak"></div>

<div id="signup">
<h1 id="signupTitle">Yes it is That Simple!</h1>
<P id="signupInfo">
Want to join hotel me and start booking your next adventures for killer prices? Just fill out the simple form below to get an account and away you go!
</P>



<form id="signupField" action="register.php" method="post">
First Name:<br>
<input type="text" name="FN" size="auto"/><br>
Last Name:<br>
<input type="text" name="LN" size="auto"/><br>
Street Address:<br>
<input type="text" name="SA" size="auto"/><br>
City:<br>
<input type="text" name="City" size="auto"/><br>
State:<br>
<input type="text" name="ST" size="auto"/><br>
Zip:<br>
<input type="text" name="Zip" size="auto"/><br>
Email Address:<br>
<input type="text" name="Email" size="auto"/><br>
Password:<br>
<input type="password" name="Password1" size="auto"/><br>
Re-Enter Password:<br>
<input type="password" name="Password2" size="auto"/><br>
<input type="submit" value="submit" name="submit"/>
</form>
</div>
</body>
</HTML>


